--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2
-- Dumped by pg_dump version 16.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE sunbridge;
--
-- Name: sunbridge; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE sunbridge WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE sunbridge OWNER TO postgres;

\connect sunbridge

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cliente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cliente (
    clienteid integer NOT NULL,
    usuarioid integer,
    cedula character varying(12),
    nome character varying(40),
    data_nascimento date,
    genero character(1),
    email character varying(60),
    telefone character varying(20),
    data_cadastro date,
    ativo boolean,
    descricao character varying(255),
    divida numeric(10,2),
    rua character varying(60),
    bairro character varying(60),
    cidade character varying(50),
    provincia character varying(50),
    canton character varying(50),
    distrito character varying(50),
    codigo_postal integer,
    complemento character varying(60)
);


ALTER TABLE public.cliente OWNER TO postgres;

--
-- Name: TABLE cliente; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.cliente IS 'Tabela que armazena os dados dos clientes.';


--
-- Name: COLUMN cliente.clienteid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cliente.clienteid IS 'Identificador único do cliente (Chave Primária).';


--
-- Name: COLUMN cliente.usuarioid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cliente.usuarioid IS 'Referência ao usuário responsável pelo cliente.';


--
-- Name: COLUMN cliente.cedula; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cliente.cedula IS 'Identificação fiscal do cliente.';


--
-- Name: COLUMN cliente.nome; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cliente.nome IS 'Nome completo do cliente.';


--
-- Name: COLUMN cliente.data_nascimento; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cliente.data_nascimento IS 'Data de nascimento do cliente.';


--
-- Name: COLUMN cliente.genero; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cliente.genero IS 'Gênero do cliente (M para masculino, F para feminino).';


--
-- Name: COLUMN cliente.email; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cliente.email IS 'Endereço de e-mail do cliente (único).';


--
-- Name: COLUMN cliente.telefone; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cliente.telefone IS 'Número de telefone do cliente.';


--
-- Name: COLUMN cliente.data_cadastro; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cliente.data_cadastro IS 'Data de cadastro do cliente no sistema.';


--
-- Name: COLUMN cliente.ativo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cliente.ativo IS 'Status ativo ou inativo do cliente.';


--
-- Name: COLUMN cliente.descricao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cliente.descricao IS 'Informações adicionais sobre o cliente.';


--
-- Name: COLUMN cliente.divida; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cliente.divida IS 'Dívida atual do cliente.';


--
-- Name: COLUMN cliente.rua; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cliente.rua IS 'Rua do endereço do cliente.';


--
-- Name: COLUMN cliente.bairro; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cliente.bairro IS 'Bairro do endereço do cliente.';


--
-- Name: COLUMN cliente.cidade; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cliente.cidade IS 'Cidade do cliente.';


--
-- Name: COLUMN cliente.provincia; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cliente.provincia IS 'Província do cliente.';


--
-- Name: COLUMN cliente.canton; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cliente.canton IS 'Cantão do cliente.';


--
-- Name: COLUMN cliente.distrito; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cliente.distrito IS 'Distrito do cliente.';


--
-- Name: COLUMN cliente.codigo_postal; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cliente.codigo_postal IS 'Código postal do cliente.';


--
-- Name: COLUMN cliente.complemento; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cliente.complemento IS 'Complemento do endereço do cliente.';


--
-- Name: cliente_logistica; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cliente_logistica (
    logisticalid integer NOT NULL,
    ped_venda integer,
    cedula character varying(12),
    data_entrega date,
    nome character varying(40),
    genero character(1),
    data_nascimento date,
    email character varying(60),
    telefone character varying(20),
    data_cadastro date,
    rua character varying(60),
    bairro character varying(255),
    cidade character varying(255),
    provincia character varying(255),
    canton character varying(50),
    distrito character varying(50),
    codigo_postal integer,
    complemento character varying(60)
);


ALTER TABLE public.cliente_logistica OWNER TO postgres;

--
-- Name: TABLE cliente_logistica; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.cliente_logistica IS 'Tabela que armazena informações sobre a logística dos pedidos entregues aos clientes.';


--
-- Name: COLUMN cliente_logistica.logisticalid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cliente_logistica.logisticalid IS 'Identificador único da logística (Chave Primária).';


--
-- Name: COLUMN cliente_logistica.ped_venda; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cliente_logistica.ped_venda IS 'Referência ao pedido de venda associado.';


--
-- Name: COLUMN cliente_logistica.cedula; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cliente_logistica.cedula IS 'Identificação fiscal do cliente.';


--
-- Name: COLUMN cliente_logistica.data_entrega; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cliente_logistica.data_entrega IS 'Data de entrega dos produtos ao cliente.';


--
-- Name: COLUMN cliente_logistica.nome; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cliente_logistica.nome IS 'Nome da pessoa responsável pelo recebimento do pedido.';


--
-- Name: COLUMN cliente_logistica.genero; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cliente_logistica.genero IS 'Gênero da pessoa (M para masculino, F para feminino).';


--
-- Name: COLUMN cliente_logistica.data_nascimento; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cliente_logistica.data_nascimento IS 'Data de nascimento da pessoa responsável.';


--
-- Name: COLUMN cliente_logistica.email; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cliente_logistica.email IS 'Endereço de e-mail para contato.';


--
-- Name: COLUMN cliente_logistica.telefone; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cliente_logistica.telefone IS 'Número de telefone para contato.';


--
-- Name: COLUMN cliente_logistica.data_cadastro; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cliente_logistica.data_cadastro IS 'Data de cadastro do cliente para logística.';


--
-- Name: COLUMN cliente_logistica.rua; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cliente_logistica.rua IS 'Rua do endereço de entrega.';


--
-- Name: COLUMN cliente_logistica.bairro; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cliente_logistica.bairro IS 'Bairro do endereço de entrega.';


--
-- Name: COLUMN cliente_logistica.cidade; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cliente_logistica.cidade IS 'Cidade de entrega do pedido.';


--
-- Name: COLUMN cliente_logistica.provincia; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cliente_logistica.provincia IS 'Província de entrega do pedido.';


--
-- Name: COLUMN cliente_logistica.canton; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cliente_logistica.canton IS 'Cantão de entrega do pedido.';


--
-- Name: COLUMN cliente_logistica.distrito; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cliente_logistica.distrito IS 'Distrito de entrega do pedido.';


--
-- Name: COLUMN cliente_logistica.codigo_postal; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cliente_logistica.codigo_postal IS 'Código postal do endereço de entrega.';


--
-- Name: COLUMN cliente_logistica.complemento; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cliente_logistica.complemento IS 'Complemento do endereço de entrega.';


--
-- Name: empresa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.empresa (
    companyid integer NOT NULL,
    nome character varying(40) NOT NULL,
    websiteurl character varying(255),
    email character varying(60),
    telefone character varying(20),
    cidade character varying(255),
    provincia character varying(255),
    data_fundacao date,
    cedula_juridica character varying(12),
    setor character varying(100),
    numero_licenca character varying(25),
    rua character varying(60),
    bairro character varying(60),
    canton character varying(50),
    distrito character varying(50),
    codigo_postal integer,
    complemento character varying(60)
);


ALTER TABLE public.empresa OWNER TO postgres;

--
-- Name: TABLE empresa; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.empresa IS 'Tabela que armazena as informações das empresas relacionadas à comercialização de painéis solares.';


--
-- Name: COLUMN empresa.companyid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.empresa.companyid IS 'Identificador único da empresa (Chave Primária).';


--
-- Name: COLUMN empresa.nome; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.empresa.nome IS 'Nome completo da empresa.';


--
-- Name: COLUMN empresa.websiteurl; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.empresa.websiteurl IS 'URL do site da empresa.';


--
-- Name: COLUMN empresa.email; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.empresa.email IS 'Endereço de e-mail de contato da empresa.';


--
-- Name: COLUMN empresa.telefone; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.empresa.telefone IS 'Número de telefone de contato da empresa.';


--
-- Name: COLUMN empresa.cidade; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.empresa.cidade IS 'Cidade onde a empresa está localizada.';


--
-- Name: COLUMN empresa.provincia; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.empresa.provincia IS 'Província onde a empresa está localizada.';


--
-- Name: COLUMN empresa.data_fundacao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.empresa.data_fundacao IS 'Data de fundação da empresa.';


--
-- Name: COLUMN empresa.cedula_juridica; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.empresa.cedula_juridica IS 'Número de identificação fiscal da empresa.';


--
-- Name: COLUMN empresa.setor; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.empresa.setor IS 'Setor de atuação da empresa, como energia ou serviços.';


--
-- Name: COLUMN empresa.numero_licenca; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.empresa.numero_licenca IS 'Número de licença de operação da empresa.';


--
-- Name: COLUMN empresa.rua; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.empresa.rua IS 'Rua do endereço da empresa.';


--
-- Name: COLUMN empresa.bairro; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.empresa.bairro IS 'Bairro do endereço da empresa.';


--
-- Name: COLUMN empresa.canton; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.empresa.canton IS 'Cantão onde a empresa está localizada.';


--
-- Name: COLUMN empresa.distrito; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.empresa.distrito IS 'Distrito onde a empresa está localizada.';


--
-- Name: COLUMN empresa.codigo_postal; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.empresa.codigo_postal IS 'Código postal do endereço da empresa.';


--
-- Name: COLUMN empresa.complemento; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.empresa.complemento IS 'Complemento do endereço, como número e detalhes adicionais.';


--
-- Name: estoque; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.estoque (
    estoqueid integer NOT NULL,
    rua character varying(60),
    prateleira character varying(30),
    peso integer,
    data_entrada date,
    data_saida date,
    valor_compra numeric(19,2),
    valor_venda numeric(19,2)
);


ALTER TABLE public.estoque OWNER TO postgres;

--
-- Name: TABLE estoque; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.estoque IS 'Tabela para controlar o estoque de itens da empresa.';


--
-- Name: COLUMN estoque.estoqueid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.estoque.estoqueid IS 'Identificador único do estoque (Chave Primária).';


--
-- Name: COLUMN estoque.rua; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.estoque.rua IS 'Localização do estoque na rua específica.';


--
-- Name: COLUMN estoque.prateleira; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.estoque.prateleira IS 'Prateleira onde o item está armazenado.';


--
-- Name: COLUMN estoque.peso; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.estoque.peso IS 'Peso dos itens armazenados no estoque.';


--
-- Name: COLUMN estoque.data_entrada; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.estoque.data_entrada IS 'Data de entrada dos itens no estoque.';


--
-- Name: COLUMN estoque.data_saida; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.estoque.data_saida IS 'Data de saída dos itens do estoque.';


--
-- Name: COLUMN estoque.valor_compra; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.estoque.valor_compra IS 'Valor de compra dos itens armazenados.';


--
-- Name: COLUMN estoque.valor_venda; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.estoque.valor_venda IS 'Valor de venda dos itens armazenados.';


--
-- Name: estoque_item_venda; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.estoque_item_venda (
    estoqueid integer NOT NULL,
    item_vendaid integer NOT NULL
);


ALTER TABLE public.estoque_item_venda OWNER TO postgres;

--
-- Name: TABLE estoque_item_venda; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.estoque_item_venda IS 'Tabela de relacionamento entre estoque e itens vendidos.';


--
-- Name: COLUMN estoque_item_venda.estoqueid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.estoque_item_venda.estoqueid IS 'Identificador do estoque relacionado.';


--
-- Name: COLUMN estoque_item_venda.item_vendaid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.estoque_item_venda.item_vendaid IS 'Identificador do item de venda relacionado.';


--
-- Name: fornecedor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fornecedor (
    fornecedorid integer NOT NULL,
    nome character varying(40) NOT NULL,
    cedula character varying(12),
    telefone character varying(20),
    rua character varying(60),
    bairro character varying(60),
    cidade character varying(50),
    provincia character varying(50),
    canton character varying(50),
    codigo_postal integer,
    distrito character varying(50),
    complemento character varying(60)
);


ALTER TABLE public.fornecedor OWNER TO postgres;

--
-- Name: TABLE fornecedor; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.fornecedor IS 'Tabela que armazena informações dos fornecedores de materiais ou produtos.';


--
-- Name: COLUMN fornecedor.fornecedorid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.fornecedor.fornecedorid IS 'Identificador único do fornecedor (Chave Primária).';


--
-- Name: COLUMN fornecedor.nome; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.fornecedor.nome IS 'Nome do fornecedor.';


--
-- Name: COLUMN fornecedor.cedula; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.fornecedor.cedula IS 'Identificação fiscal do fornecedor.';


--
-- Name: COLUMN fornecedor.telefone; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.fornecedor.telefone IS 'Número de telefone do fornecedor.';


--
-- Name: COLUMN fornecedor.rua; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.fornecedor.rua IS 'Rua do endereço do fornecedor.';


--
-- Name: COLUMN fornecedor.bairro; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.fornecedor.bairro IS 'Bairro do endereço do fornecedor.';


--
-- Name: COLUMN fornecedor.cidade; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.fornecedor.cidade IS 'Cidade onde o fornecedor está localizado.';


--
-- Name: COLUMN fornecedor.provincia; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.fornecedor.provincia IS 'Província onde o fornecedor está localizado.';


--
-- Name: COLUMN fornecedor.canton; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.fornecedor.canton IS 'Cantão onde o fornecedor está localizado.';


--
-- Name: COLUMN fornecedor.codigo_postal; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.fornecedor.codigo_postal IS 'Código postal do endereço do fornecedor.';


--
-- Name: COLUMN fornecedor.distrito; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.fornecedor.distrito IS 'Distrito onde o fornecedor está localizado.';


--
-- Name: COLUMN fornecedor.complemento; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.fornecedor.complemento IS 'Complemento do endereço do fornecedor.';


--
-- Name: item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.item (
    it_cod integer NOT NULL,
    nome character varying(40) NOT NULL,
    descricao character varying(255),
    quantidade integer,
    valor numeric(19,2),
    categoria character varying(100),
    estoqueid integer
);


ALTER TABLE public.item OWNER TO postgres;

--
-- Name: TABLE item; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.item IS 'Tabela que armazena informações sobre os itens disponíveis no estoque.';


--
-- Name: COLUMN item.it_cod; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.item.it_cod IS 'Identificador único de cada item (Chave Primária).';


--
-- Name: COLUMN item.nome; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.item.nome IS 'Nome do item (por exemplo, painel solar, inversor).';


--
-- Name: COLUMN item.descricao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.item.descricao IS 'Descrição detalhada do item.';


--
-- Name: COLUMN item.quantidade; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.item.quantidade IS 'Quantidade de itens disponíveis.';


--
-- Name: COLUMN item.valor; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.item.valor IS 'Valor unitário do item.';


--
-- Name: COLUMN item.categoria; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.item.categoria IS 'Categoria a que o item pertence.';


--
-- Name: COLUMN item.estoqueid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.item.estoqueid IS 'Referência ao estoque onde o item está armazenado.';


--
-- Name: item_venda; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.item_venda (
    item_vendaid integer NOT NULL,
    ped_venda integer,
    it_cod integer,
    quantidade integer,
    valor_prod numeric(19,2),
    descricao character varying(255),
    marca character varying(255),
    garantia integer,
    composicao character varying(255),
    origem character varying(255)
);


ALTER TABLE public.item_venda OWNER TO postgres;

--
-- Name: TABLE item_venda; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.item_venda IS 'Tabela que armazena informações dos itens vendidos aos clientes.';


--
-- Name: COLUMN item_venda.item_vendaid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.item_venda.item_vendaid IS 'Identificador único do item de venda (Chave Primária).';


--
-- Name: COLUMN item_venda.ped_venda; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.item_venda.ped_venda IS 'Referência ao pedido de venda associado.';


--
-- Name: COLUMN item_venda.it_cod; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.item_venda.it_cod IS 'Referência ao código do item vendido.';


--
-- Name: COLUMN item_venda.quantidade; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.item_venda.quantidade IS 'Quantidade de itens vendidos.';


--
-- Name: COLUMN item_venda.valor_prod; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.item_venda.valor_prod IS 'Valor do produto vendido.';


--
-- Name: COLUMN item_venda.descricao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.item_venda.descricao IS 'Descrição do item vendido.';


--
-- Name: COLUMN item_venda.marca; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.item_venda.marca IS 'Marca do item vendido.';


--
-- Name: COLUMN item_venda.garantia; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.item_venda.garantia IS 'Informação sobre garantia do item.';


--
-- Name: COLUMN item_venda.composicao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.item_venda.composicao IS 'Composição do item vendido.';


--
-- Name: COLUMN item_venda.origem; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.item_venda.origem IS 'Origem do item vendido.';


--
-- Name: pagamento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pagamento (
    pagamentoid integer NOT NULL,
    clienteid integer,
    data_pagamento date,
    valor_pago numeric(10,2),
    forma_pagamento character varying(20),
    status_pagamento character varying(20)
);


ALTER TABLE public.pagamento OWNER TO postgres;

--
-- Name: TABLE pagamento; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.pagamento IS 'Tabela que armazena registros de pagamentos realizados pelos clientes.';


--
-- Name: COLUMN pagamento.pagamentoid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.pagamento.pagamentoid IS 'Identificador único do pagamento (Chave Primária).';


--
-- Name: COLUMN pagamento.clienteid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.pagamento.clienteid IS 'Referência ao cliente que realizou o pagamento.';


--
-- Name: COLUMN pagamento.data_pagamento; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.pagamento.data_pagamento IS 'Data do pagamento realizado.';


--
-- Name: COLUMN pagamento.valor_pago; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.pagamento.valor_pago IS 'Valor total pago pelo cliente.';


--
-- Name: COLUMN pagamento.forma_pagamento; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.pagamento.forma_pagamento IS 'Método utilizado para o pagamento.';


--
-- Name: COLUMN pagamento.status_pagamento; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.pagamento.status_pagamento IS 'Status atual do pagamento (Pago ou pendente).';


--
-- Name: pagamento_fornecedor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pagamento_fornecedor (
    pagamento_fornecedorid integer NOT NULL,
    data_pagamento date,
    valor numeric(19,2),
    forma_pagamento character varying(20)
);


ALTER TABLE public.pagamento_fornecedor OWNER TO postgres;

--
-- Name: TABLE pagamento_fornecedor; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.pagamento_fornecedor IS 'Tabela que armazena informações sobre os pagamentos realizados a fornecedores.';


--
-- Name: COLUMN pagamento_fornecedor.pagamento_fornecedorid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.pagamento_fornecedor.pagamento_fornecedorid IS 'Identificador único do pagamento ao fornecedor (Chave Primária).';


--
-- Name: COLUMN pagamento_fornecedor.data_pagamento; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.pagamento_fornecedor.data_pagamento IS 'Data em que o pagamento foi realizado.';


--
-- Name: COLUMN pagamento_fornecedor.valor; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.pagamento_fornecedor.valor IS 'Valor do pagamento ao fornecedor.';


--
-- Name: COLUMN pagamento_fornecedor.forma_pagamento; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.pagamento_fornecedor.forma_pagamento IS 'Forma de pagamento utilizada.';


--
-- Name: pedido_compra; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pedido_compra (
    ped_compra integer NOT NULL,
    data_compra date,
    data_entrega date,
    valor numeric(19,2),
    desconto numeric(19,2),
    usuarioid integer,
    pagamento_fornecedorid integer,
    fornecedorid integer
);


ALTER TABLE public.pedido_compra OWNER TO postgres;

--
-- Name: TABLE pedido_compra; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.pedido_compra IS 'Tabela para armazenar pedidos de compra feitos pela empresa.';


--
-- Name: COLUMN pedido_compra.ped_compra; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.pedido_compra.ped_compra IS 'Identificador único do pedido de compra (Chave Primária).';


--
-- Name: COLUMN pedido_compra.data_compra; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.pedido_compra.data_compra IS 'Data em que o pedido de compra foi realizado.';


--
-- Name: COLUMN pedido_compra.data_entrega; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.pedido_compra.data_entrega IS 'Data prevista para a entrega do pedido.';


--
-- Name: COLUMN pedido_compra.valor; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.pedido_compra.valor IS 'Valor total do pedido de compra.';


--
-- Name: COLUMN pedido_compra.desconto; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.pedido_compra.desconto IS 'Valor do desconto aplicado ao pedido.';


--
-- Name: COLUMN pedido_compra.usuarioid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.pedido_compra.usuarioid IS 'Identificador do usuário que realizou o pedido.';


--
-- Name: COLUMN pedido_compra.pagamento_fornecedorid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.pedido_compra.pagamento_fornecedorid IS 'Identificador do pagamento associado ao fornecedor.';


--
-- Name: COLUMN pedido_compra.fornecedorid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.pedido_compra.fornecedorid IS 'Identificador do fornecedor para o pedido.';


--
-- Name: pedido_fornecedor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pedido_fornecedor (
    pedido_forid integer NOT NULL,
    quantidade integer,
    valor numeric(19,2),
    pedido_compra integer,
    estoqueid integer
);


ALTER TABLE public.pedido_fornecedor OWNER TO postgres;

--
-- Name: TABLE pedido_fornecedor; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.pedido_fornecedor IS 'Tabela que armazena os detalhes dos pedidos feitos aos fornecedores.';


--
-- Name: COLUMN pedido_fornecedor.pedido_forid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.pedido_fornecedor.pedido_forid IS 'Identificador único do pedido ao fornecedor (Chave Primária).';


--
-- Name: COLUMN pedido_fornecedor.quantidade; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.pedido_fornecedor.quantidade IS 'Quantidade de itens solicitados no pedido.';


--
-- Name: COLUMN pedido_fornecedor.valor; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.pedido_fornecedor.valor IS 'Valor total do pedido.';


--
-- Name: COLUMN pedido_fornecedor.pedido_compra; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.pedido_fornecedor.pedido_compra IS 'Referência ao pedido de compra associado.';


--
-- Name: COLUMN pedido_fornecedor.estoqueid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.pedido_fornecedor.estoqueid IS 'Identificador do estoque onde os itens serão armazenados.';


--
-- Name: pedido_venda; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pedido_venda (
    ped_venda integer NOT NULL,
    clienteid integer,
    data_venda date,
    data_instalacao date,
    valor numeric(19,2),
    desconto numeric(19,2)
);


ALTER TABLE public.pedido_venda OWNER TO postgres;

--
-- Name: TABLE pedido_venda; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.pedido_venda IS 'Tabela que armazena os pedidos de venda realizados por clientes.';


--
-- Name: COLUMN pedido_venda.ped_venda; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.pedido_venda.ped_venda IS 'Identificador único do pedido de venda (Chave Primária).';


--
-- Name: COLUMN pedido_venda.clienteid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.pedido_venda.clienteid IS 'Referência ao cliente que realizou o pedido.';


--
-- Name: COLUMN pedido_venda.data_venda; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.pedido_venda.data_venda IS 'Data em que o pedido foi feito.';


--
-- Name: COLUMN pedido_venda.data_instalacao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.pedido_venda.data_instalacao IS 'Data de instalação dos produtos vendidos.';


--
-- Name: COLUMN pedido_venda.valor; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.pedido_venda.valor IS 'Valor total do pedido de venda.';


--
-- Name: COLUMN pedido_venda.desconto; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.pedido_venda.desconto IS 'Desconto aplicado no pedido de venda.';


--
-- Name: usuario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuario (
    usuarioid integer NOT NULL,
    usuarioid_fk integer,
    companyid integer,
    nome character varying(40) NOT NULL,
    genero character(1),
    data_entrada date,
    tipo integer,
    cedula character varying(15),
    data_nascimento date,
    departamento character varying(100),
    data_admissao date,
    salario numeric(10,2),
    ativo boolean,
    telefone character varying(20),
    email character varying(60),
    endereco character varying(60),
    rua character varying(60),
    bairro character varying(60),
    cidade character varying(50),
    canton character varying(50),
    distrito character varying(50),
    codigo_postal integer,
    complemento character varying(60)
);


ALTER TABLE public.usuario OWNER TO postgres;

--
-- Name: TABLE usuario; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.usuario IS 'Tabela que registra os dados dos funcionários ou usuários do sistema.';


--
-- Name: COLUMN usuario.usuarioid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.usuario.usuarioid IS 'Identificador único do usuário (Chave Primária).';


--
-- Name: COLUMN usuario.usuarioid_fk; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.usuario.usuarioid_fk IS 'Referência para outro usuário, geralmente um supervisor ou gerente.';


--
-- Name: COLUMN usuario.companyid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.usuario.companyid IS 'Identificador da empresa à qual o usuário está associado.';


--
-- Name: COLUMN usuario.nome; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.usuario.nome IS 'Nome completo do usuário.';


--
-- Name: COLUMN usuario.genero; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.usuario.genero IS 'Gênero do usuário (M para masculino, F para feminino).';


--
-- Name: COLUMN usuario.data_entrada; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.usuario.data_entrada IS 'Data de entrada do usuário na empresa.';


--
-- Name: COLUMN usuario.tipo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.usuario.tipo IS 'Tipo ou cargo do usuário.';


--
-- Name: COLUMN usuario.cedula; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.usuario.cedula IS 'Número de identificação fiscal do usuário.';


--
-- Name: COLUMN usuario.data_nascimento; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.usuario.data_nascimento IS 'Data de nascimento do usuário.';


--
-- Name: COLUMN usuario.departamento; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.usuario.departamento IS 'Departamento onde o usuário trabalha.';


--
-- Name: COLUMN usuario.data_admissao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.usuario.data_admissao IS 'Data de admissão do usuário.';


--
-- Name: COLUMN usuario.salario; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.usuario.salario IS 'Salário mensal do usuário.';


--
-- Name: COLUMN usuario.ativo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.usuario.ativo IS 'Indica se o usuário está ativo (TRUE) ou inativo (FALSE).';


--
-- Name: COLUMN usuario.telefone; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.usuario.telefone IS 'Número de telefone do usuário.';


--
-- Name: COLUMN usuario.email; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.usuario.email IS 'Endereço de e-mail do usuário.';


--
-- Name: COLUMN usuario.endereco; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.usuario.endereco IS 'Endereço completo do usuário.';


--
-- Name: COLUMN usuario.rua; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.usuario.rua IS 'Rua do endereço do usuário.';


--
-- Name: COLUMN usuario.bairro; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.usuario.bairro IS 'Bairro do endereço do usuário.';


--
-- Name: COLUMN usuario.cidade; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.usuario.cidade IS 'Cidade onde o usuário reside.';


--
-- Name: COLUMN usuario.canton; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.usuario.canton IS 'Cantão do endereço do usuário.';


--
-- Name: COLUMN usuario.distrito; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.usuario.distrito IS 'Distrito do endereço do usuário.';


--
-- Name: COLUMN usuario.codigo_postal; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.usuario.codigo_postal IS 'Código postal do endereço do usuário.';


--
-- Name: COLUMN usuario.complemento; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.usuario.complemento IS 'Complemento do endereço do usuário.';


--
-- Data for Name: cliente; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/4939.dat

--
-- Data for Name: cliente_logistica; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/4944.dat

--
-- Data for Name: empresa; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/4931.dat

--
-- Data for Name: estoque; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/4935.dat

--
-- Data for Name: estoque_item_venda; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/4943.dat

--
-- Data for Name: fornecedor; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/4933.dat

--
-- Data for Name: item; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/4938.dat

--
-- Data for Name: item_venda; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/4942.dat

--
-- Data for Name: pagamento; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/4940.dat

--
-- Data for Name: pagamento_fornecedor; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/4934.dat

--
-- Data for Name: pedido_compra; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/4936.dat

--
-- Data for Name: pedido_fornecedor; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/4937.dat

--
-- Data for Name: pedido_venda; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/4941.dat

--
-- Data for Name: usuario; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/4932.dat

--
-- Name: cliente cliente_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT cliente_email_key UNIQUE (email);


--
-- Name: cliente_logistica cliente_logistica_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente_logistica
    ADD CONSTRAINT cliente_logistica_email_key UNIQUE (email);


--
-- Name: cliente_logistica cliente_logistica_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente_logistica
    ADD CONSTRAINT cliente_logistica_pkey PRIMARY KEY (logisticalid);


--
-- Name: cliente cliente_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT cliente_pkey PRIMARY KEY (clienteid);


--
-- Name: empresa empresa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.empresa
    ADD CONSTRAINT empresa_pkey PRIMARY KEY (companyid);


--
-- Name: estoque_item_venda estoque_item_venda_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estoque_item_venda
    ADD CONSTRAINT estoque_item_venda_pkey PRIMARY KEY (estoqueid, item_vendaid);


--
-- Name: estoque estoque_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estoque
    ADD CONSTRAINT estoque_pkey PRIMARY KEY (estoqueid);


--
-- Name: fornecedor fornecedor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fornecedor
    ADD CONSTRAINT fornecedor_pkey PRIMARY KEY (fornecedorid);


--
-- Name: item item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item
    ADD CONSTRAINT item_pkey PRIMARY KEY (it_cod);


--
-- Name: item_venda item_venda_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_venda
    ADD CONSTRAINT item_venda_pkey PRIMARY KEY (item_vendaid);


--
-- Name: pagamento_fornecedor pagamento_fornecedor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pagamento_fornecedor
    ADD CONSTRAINT pagamento_fornecedor_pkey PRIMARY KEY (pagamento_fornecedorid);


--
-- Name: pagamento pagamento_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pagamento
    ADD CONSTRAINT pagamento_pkey PRIMARY KEY (pagamentoid);


--
-- Name: pedido_compra pedido_compra_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_compra
    ADD CONSTRAINT pedido_compra_pkey PRIMARY KEY (ped_compra);


--
-- Name: pedido_fornecedor pedido_fornecedor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_fornecedor
    ADD CONSTRAINT pedido_fornecedor_pkey PRIMARY KEY (pedido_forid);


--
-- Name: pedido_venda pedido_venda_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_venda
    ADD CONSTRAINT pedido_venda_pkey PRIMARY KEY (ped_venda);


--
-- Name: usuario usuario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_pkey PRIMARY KEY (usuarioid);


--
-- Name: cliente_logistica cliente_logistica_ped_venda_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente_logistica
    ADD CONSTRAINT cliente_logistica_ped_venda_fkey FOREIGN KEY (ped_venda) REFERENCES public.pedido_venda(ped_venda);


--
-- Name: cliente cliente_usuarioid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT cliente_usuarioid_fkey FOREIGN KEY (usuarioid) REFERENCES public.usuario(usuarioid);


--
-- Name: estoque_item_venda estoque_item_venda_estoqueid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estoque_item_venda
    ADD CONSTRAINT estoque_item_venda_estoqueid_fkey FOREIGN KEY (estoqueid) REFERENCES public.estoque(estoqueid);


--
-- Name: estoque_item_venda estoque_item_venda_item_vendaid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estoque_item_venda
    ADD CONSTRAINT estoque_item_venda_item_vendaid_fkey FOREIGN KEY (item_vendaid) REFERENCES public.item_venda(item_vendaid);


--
-- Name: item item_estoqueid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item
    ADD CONSTRAINT item_estoqueid_fkey FOREIGN KEY (estoqueid) REFERENCES public.estoque(estoqueid);


--
-- Name: item_venda item_venda_it_cod_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_venda
    ADD CONSTRAINT item_venda_it_cod_fkey FOREIGN KEY (it_cod) REFERENCES public.item(it_cod);


--
-- Name: item_venda item_venda_ped_venda_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_venda
    ADD CONSTRAINT item_venda_ped_venda_fkey FOREIGN KEY (ped_venda) REFERENCES public.pedido_venda(ped_venda);


--
-- Name: pagamento pagamento_clienteid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pagamento
    ADD CONSTRAINT pagamento_clienteid_fkey FOREIGN KEY (clienteid) REFERENCES public.cliente(clienteid);


--
-- Name: pedido_compra pedido_compra_fornecedorid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_compra
    ADD CONSTRAINT pedido_compra_fornecedorid_fkey FOREIGN KEY (fornecedorid) REFERENCES public.fornecedor(fornecedorid);


--
-- Name: pedido_compra pedido_compra_pagamento_fornecedorid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_compra
    ADD CONSTRAINT pedido_compra_pagamento_fornecedorid_fkey FOREIGN KEY (pagamento_fornecedorid) REFERENCES public.pagamento_fornecedor(pagamento_fornecedorid);


--
-- Name: pedido_compra pedido_compra_usuarioid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_compra
    ADD CONSTRAINT pedido_compra_usuarioid_fkey FOREIGN KEY (usuarioid) REFERENCES public.usuario(usuarioid);


--
-- Name: pedido_fornecedor pedido_fornecedor_estoqueid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_fornecedor
    ADD CONSTRAINT pedido_fornecedor_estoqueid_fkey FOREIGN KEY (estoqueid) REFERENCES public.estoque(estoqueid);


--
-- Name: pedido_fornecedor pedido_fornecedor_pedido_compra_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_fornecedor
    ADD CONSTRAINT pedido_fornecedor_pedido_compra_fkey FOREIGN KEY (pedido_compra) REFERENCES public.pedido_compra(ped_compra);


--
-- Name: pedido_venda pedido_venda_clienteid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_venda
    ADD CONSTRAINT pedido_venda_clienteid_fkey FOREIGN KEY (clienteid) REFERENCES public.cliente(clienteid);


--
-- Name: usuario usuario_companyid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_companyid_fkey FOREIGN KEY (companyid) REFERENCES public.empresa(companyid);


--
-- Name: usuario usuario_usuarioid_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_usuarioid_fk_fkey FOREIGN KEY (usuarioid_fk) REFERENCES public.usuario(usuarioid);


--
-- Name: DATABASE sunbridge; Type: ACL; Schema: -; Owner: postgres
--

GRANT CONNECT ON DATABASE sunbridge TO sunbridgejava;


--
-- Name: TABLE cliente; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.cliente TO sunbridgejava;


--
-- Name: TABLE cliente_logistica; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.cliente_logistica TO sunbridgejava;


--
-- Name: TABLE empresa; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.empresa TO sunbridgejava;


--
-- Name: TABLE estoque; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.estoque TO sunbridgejava;


--
-- Name: TABLE estoque_item_venda; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.estoque_item_venda TO sunbridgejava;


--
-- Name: TABLE fornecedor; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fornecedor TO sunbridgejava;


--
-- Name: TABLE item; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.item TO sunbridgejava;


--
-- Name: TABLE item_venda; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.item_venda TO sunbridgejava;


--
-- Name: TABLE pagamento; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.pagamento TO sunbridgejava;


--
-- Name: TABLE pagamento_fornecedor; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.pagamento_fornecedor TO sunbridgejava;


--
-- Name: TABLE pedido_compra; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.pedido_compra TO sunbridgejava;


--
-- Name: TABLE pedido_fornecedor; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.pedido_fornecedor TO sunbridgejava;


--
-- Name: TABLE pedido_venda; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.pedido_venda TO sunbridgejava;


--
-- Name: TABLE usuario; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.usuario TO sunbridgejava;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO sunbridgejava;


--
-- PostgreSQL database dump complete
--

